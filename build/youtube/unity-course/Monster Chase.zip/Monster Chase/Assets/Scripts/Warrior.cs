

public class Warrior
{

    public static string name;
    public static int power;

    

}
