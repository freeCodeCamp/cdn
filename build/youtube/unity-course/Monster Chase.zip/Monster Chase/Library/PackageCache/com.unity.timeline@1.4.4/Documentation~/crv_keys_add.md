# Adding keys

The Curves view provides the following methods for adding keys:

* Right-click on an animation curve and select **Add Key**. This method adds a key at the location of the right-click.
* Double-click on an animation curve. This method adds a key at the location of the Double-click.
